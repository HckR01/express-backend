export const DB_NAME = "videotube";
